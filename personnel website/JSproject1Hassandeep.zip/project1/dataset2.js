var phones=new Object(); 
phones['initial'] = ['null','Select the type of gift','select','Men','Women'];

phones['Men'] = ['null','Select what you want','select','Shirts','Tie','Shoes'];
phones['Women'] = ['null','Select what you want','select','Dresses','Jewellary',];


phones['Shirts'] = ['null','Select the color of shirt','select','Blue','Black'];
phones['Blue']=['shirtBlue.jpg','null','null','null','null'];
phones['Black']=['shirtBlack.jpg','null','null','null','null'];

phones['Tie'] = ['null','Select the tie','select','Red','Grey','Copper','Yellow'];
phones['Red']=['redLine.jpg','null','null','null','null'];
phones['Grey']=['grey.jpg','null','null','null','null'];
phones['Copper']=['copper.jpg','null','null','null','null'];
phones['Yellow']=['yellow.jpg','null','null','null','null'];

phones['Shoes'] = ['null','Select the shoes type','select','Sport','Formal'];
phones['Sport']=['sport.jpg','null','null','null','null'];
phones['Formal']=['formal.jpg','null','null','null','null'];

phones['Dresses'] = ['null','Select what you want','select','Winter','Summer'];
phones['Winter'] = ['null','Select what winter dress you looking','select','Sweaters','Leggings'];
phones['Summer'] = ['null','Select what summer clothes','select','Tops','Skirts','Tanks'];

phones['Jewellary'] =['null','Select what you want','select','Earing','Neckpiece'];
phones['Earing']=['earing.jpg','null','null','null','null'];
phones['Neckpiece'] =['neckpiece.jpg','null','null','null','null'];


phones['Sweaters'] =['null','Select what sweater','select','Pink','Green'];
phones['Pink'] =['pink.jpg','null','null','null','null'];
phones['Green']=['green.JPG','null','null','null','null'];

phones['Leggings']=['legging.jpg','null','null','null','null'];

phones['Tops']=['top.jpg','null','null','null','null'];
phones['Skirts']=['skirts.jpg','null','null','null','null'];
phones['Tanks']=['tank.jpg','null','null','null','null'];